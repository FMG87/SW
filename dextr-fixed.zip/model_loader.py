# model_loader.py
# Loader mínimo para DEXTR (OpenVINO IR: dextr.xml / dextr.bin)

import numpy as np
from openvino.runtime import Core

class ModelLoader:
    def __init__(self, model_xml: str, model_bin: str):
        core = Core()
        model = core.read_model(model=model_xml, weights=model_bin)
        self.compiled = core.compile_model(model, "CPU")
        self.input = self.compiled.input(0)
        self.output = self.compiled.output(0)

    def infer(self, input_tensor: np.ndarray, preprocess: bool = False) -> np.ndarray:
        # input_tensor esperado: shape [1, 4, H, W], dtype float32
        result_map = self.compiled([input_tensor])
        return result_map[self.output]
