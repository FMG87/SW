# Copyright (C) 2018-2022 Intel Corporation
#
# SPDX-License-Identifier: MIT

import cv2
import numpy as np
import os
import importlib

# Fallback inteligente:
# - Se NÃO existir o módulo "model_loader", cai para export.ModelLoader
# - Se o módulo existir mas faltar dependência (ex.: openvino), não faz fallback (deixa o erro real aparecer)
try:
    _mod = importlib.import_module("model_loader")
    ModelLoader = getattr(_mod, "ModelLoader")
except ModuleNotFoundError as e:
    if e.name == "model_loader":
        from export import ModelLoader  # requer torch; só usado se não houver model_loader.py
    else:
        raise  # dependência faltando dentro de model_loader (ex.: openvino) -> não mascarar

class ModelHandler:
    def __init__(self):
        base_dir = os.path.abspath(os.environ.get("MODEL_PATH", "/opt/nuclio"))
        model_xml = os.path.join(base_dir, "dextr.xml")
        model_bin = os.path.join(base_dir, "dextr.bin")
        self.model = ModelLoader(model_xml, model_bin)

    # Input:
    #   image: PIL image
    #   points: [[x1,y1], [x2,y2], [x3,y3], [x4,y4], ...]
    # Output:
    #   polygon: [[x1,y1], [x2,y2], [x3,y3], [x4,y4], ...]
    #   mask: [[a, a, a, a, a, ...], [a, a, a, a, ...], ...]
    def handle(self, image, points):
        DEXTR_PADDING = 50
        DEXTR_THRESHOLD = 0.8
        DEXTR_SIZE = 512

        numpy_image = np.array(image)
        points = np.asarray(points, dtype=int)

        # bounding box (x1, y1, x2, y2)
        bounding_box = (
            max(min(points[:, 0]) - DEXTR_PADDING, 0),
            max(min(points[:, 1]) - DEXTR_PADDING, 0),
            min(max(points[:, 0]) + DEXTR_PADDING, numpy_image.shape[1] - 1),
            min(max(points[:, 1]) + DEXTR_PADDING, numpy_image.shape[0] - 1),
        )

        # recorte e resize
        numpy_cropped = np.array(image.crop(bounding_box))
        resized = cv2.resize(
            numpy_cropped, (DEXTR_SIZE, DEXTR_SIZE), interpolation=cv2.INTER_CUBIC
        ).astype(np.float32)

        # grayscale -> RGB / remover alpha
        if len(resized.shape) == 2:
            resized = cv2.cvtColor(resized, cv2.COLOR_GRAY2RGB)
        elif resized.shape[2] == 4:
            resized = resized[:, :, :3]

        # heatmap dos pontos
        points = points - [bounding_box[0], bounding_box[1]]
        points = (
            points
            * [DEXTR_SIZE / numpy_cropped.shape[1], DEXTR_SIZE / numpy_cropped.shape[0]]
        ).astype(int)

        heatmap = np.zeros(shape=resized.shape[:2], dtype=np.float64)
        for point in points:
            gx = np.arange(0, DEXTR_SIZE, 1, float) - point[0]
            gy = np.arange(0, DEXTR_SIZE, 1, float)[:, np.newaxis] - point[1]
            gaussian = np.exp(
                -4 * np.log(2) * ((gx ** 2 + gy ** 2) / 100.0)
            ).astype(np.float64)
            heatmap = np.maximum(heatmap, gaussian)

        cv2.normalize(heatmap, heatmap, 0, 255, cv2.NORM_MINMAX)

        # concatena imagem + heatmap -> [C,H,W]
        input_dextr = np.concatenate(
            (resized, heatmap[:, :, np.newaxis].astype(resized.dtype)), axis=2
        )
        input_dextr = input_dextr.transpose((2, 0, 1))

        # inferência
        pred = self.model.infer(input_dextr[np.newaxis, ...], False)[0, 0, :, :]
        pred = (pred > DEXTR_THRESHOLD).astype(np.uint8)
        pred = cv2.resize(
            pred,
            tuple(reversed(numpy_cropped.shape[:2])),
            interpolation=cv2.INTER_NEAREST,
        )

        result = np.zeros(numpy_image.shape[:2], dtype=np.uint8)
        result[
            bounding_box[1] : bounding_box[1] + pred.shape[0],
            bounding_box[0] : bounding_box[0] + pred.shape[1],
        ] = pred

        # máscara -> contorno (polígono)
        if int(cv2.__version__.split(".")[0]) > 3:
            contours = cv2.findContours(result, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        else:
            contours = cv2.findContours(result, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]

        if not contours:
            raise Exception("Nenhum contorno detectado. Não é possível construir polígono.")

        contours = max(contours, key=lambda arr: arr.size)
        if contours.shape.count(1):
            contours = np.squeeze(contours)
        if contours.size < 3 * 2:
            raise Exception("Less than three points have been detected. Cannot build a polygon.")

        polygon = [[int(p[0]), int(p[1])] for p in contours]

        return result, polygon
