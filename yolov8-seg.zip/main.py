import io
import json
import numpy as np
from PIL import Image
from ultralytics import YOLO

# CVAT -> Nuclio: init_context é chamado uma vez no cold start
def init_context(context):
    import os
    model_path = os.getenv("MODEL_PATH", "/opt/nuclio/best.pt")
    context.logger.info(f"Loading YOLOv8 model from {model_path} ...")
    context.user_data = {}
    context.user_data["model"] = YOLO(model_path)
    context.logger.info("Model loaded.")

def _read_image_from_event(event):
    body = event.body
    if isinstance(body, (bytes, bytearray)):
        return Image.open(io.BytesIO(body)).convert("RGB")
    # quando o CVAT manda multipart
    try:
        file = event.files.get("image", None)
        if file is not None:
            return Image.open(io.BytesIO(file.body)).convert("RGB")
    except Exception:
        pass
    raise RuntimeError("No image found in request")

def handler(context, event):
    model = context.user_data["model"]
    image = _read_image_from_event(event)

    # previsões (uma imagem por vez)
    results = model.predict(image, verbose=False)
    if not results:
        return context.Response(body=json.dumps({"shapes": []}),
                                headers={},
                                content_type="application/json",
                                status_code=200)

    res = results[0]
    names = res.names
    shapes = []

    # scores e classes
    scores = res.boxes.conf.cpu().numpy() if res.boxes is not None else []
    classes = res.boxes.cls.cpu().numpy().astype(int) if res.boxes is not None else []

    # máscaras -> polígonos (lista de contornos em coordenadas XY)
    # Ultralytics já disponibiliza polygons em res.masks.xy
    if getattr(res, "masks", None) is not None and res.masks.xy is not None:
        polys = res.masks.xy  # list[np.ndarray Nx2]
        for i, poly in enumerate(polys):
            pts = poly.reshape(-1, 2).tolist()
            label = names[int(classes[i])] if len(classes) > i else "object"
            score = float(scores[i]) if len(scores) > i else 0.0

            shapes.append({
                "type": "polygon",
                "label": label,
                "points": pts,          # [[x,y], ...] será aceito pelo CVAT; ele converte para o formato interno
                "occluded": False,
                "outside": False,
                "attributes": [],
                "description": "",
                "confidence": score
            })

    return context.Response(body=json.dumps({"shapes": shapes}),
                            headers={},
                            content_type="application/json",
                            status_code=200)
